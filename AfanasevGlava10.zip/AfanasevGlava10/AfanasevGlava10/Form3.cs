﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AfanasevGlava10
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // Заполняем первый узел. Используем диск C:
            TreeNode rootNode = new TreeNode(@"C:\");
            treeDirectory.Nodes.Add(rootNode);
            // Заполнеяем первый уровень и раскрываем его
            FillNodes(rootNode);
            treeDirectory.Nodes[0].Expand();
            // Заполняем второй узел. Используем диск D:
            TreeNode rootNode2 = new TreeNode(@"D:\");
            treeDirectory.Nodes.Add(rootNode2);
            FillNodes(rootNode2);
            // Не будем раскрывать его
            //treeDirectory.Nodes[1].Expand();
        }
        private void FillNodes(TreeNode dirNode)
        {
            DirectoryInfo dir = new DirectoryInfo(dirNode.FullPath);
            foreach (DirectoryInfo dirItem in dir.GetDirectories())
            {
                // Добавляем узел для каждой папки
                TreeNode newNode = new TreeNode(dirItem.Name);
                dirNode.Nodes.Add(newNode);
                newNode.Nodes.Add("*");
            }
        }
        private void treeDirectory_BeforeExpand(object sender,
         TreeViewCancelEventArgs e)
        {
            // Если найден узел со звездочкой *, то удаляем его
            // и получаем список подпапок.
            if (e.Node.Nodes[0].Text == "*")
            {
                e.Node.Nodes.Clear();
                FillNodes(e.Node);
            }
        }
    }
}
